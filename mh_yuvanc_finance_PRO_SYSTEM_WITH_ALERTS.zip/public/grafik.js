fetch("/grafik/gelirgider")
  .then(res => res.json())
  .then(data => {
    const ctx = document.getElementById("gelirgiderChart").getContext("2d");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: data.labels,
        datasets: [
          {
            label: "Gelir",
            data: data.gelir,
            backgroundColor: "green"
          },
          {
            label: "Gider",
            data: data.gider,
            backgroundColor: "red"
          }
        ]
      }
    });
  });
